
import React from 'react';
import { Contest } from '../types';
import CountdownTimer from './CountdownTimer';

interface FeaturedContestProps {
  contest: Contest;
}

const FeaturedContest: React.FC<FeaturedContestProps> = ({ contest }) => {
  return (
    <div className="mb-12 p-6 md:p-8 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 dark:from-blue-600 dark:to-purple-700 shadow-2xl text-white">
      <div className="text-center">
        <h2 className="text-sm md:text-base font-semibold uppercase tracking-widest text-blue-200">Next Contest Starts In</h2>
        <div className="my-4 md:my-6">
          <CountdownTimer targetDate={contest.startTime} />
        </div>
        <p className="text-xl md:text-2xl font-bold tracking-tight">
          {contest.name} on <span className="font-extrabold">{contest.platform}</span>
        </p>
        <p className="text-blue-100 mt-1 text-sm md:text-base">
          {contest.startTime.toLocaleString(undefined, {
            weekday: 'long',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          })}
        </p>
      </div>
    </div>
  );
};

export default FeaturedContest;
