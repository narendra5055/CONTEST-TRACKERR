
import React from 'react';
import { Contest, Platform } from '../types';

interface ContestCardProps {
  contest: Contest;
}

const PlatformLogo: React.FC<{ platform: Platform }> = ({ platform }) => {
  const platformStyles = {
    [Platform.LeetCode]: {
      bg: 'bg-leet-orange/10 dark:bg-leet-orange/20',
      text: 'text-leet-orange',
      name: 'LeetCode'
    },
    [Platform.CodeChef]: {
      bg: 'bg-codechef-brown/10 dark:bg-codechef-brown/20',
      text: 'text-codechef-brown dark:text-amber-200',
      name: 'CodeChef'
    },
    [Platform.GeeksforGeeks]: {
      bg: 'bg-gfg-green/10 dark:bg-gfg-green/20',
      text: 'text-gfg-green',
      name: 'GeeksforGeeks'
    }
  };
  const style = platformStyles[platform];

  return (
    <span className={`px-2 py-1 text-xs font-bold rounded-full ${style.bg} ${style.text}`}>
      {style.name}
    </span>
  );
};


const ContestCard: React.FC<ContestCardProps> = ({ contest }) => {
  const { name, platform, startTime, endTime, url } = contest;

  const now = new Date().getTime();
  const isOngoing = startTime.getTime() <= now && endTime.getTime() > now;

  const formatDateTime = (date: Date) => {
    return date.toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getDuration = () => {
    const diff = endTime.getTime() - startTime.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    let durationStr = '';
    if (hours > 0) durationStr += `${hours} hr `;
    if (minutes > 0) durationStr += `${minutes} min`;
    return durationStr.trim();
  };

  const formatGCALDate = (date: Date) => {
    return date.toISOString().replace(/-|:|\.\d{3}/g, '');
  };

  const gcalLink = `https://www.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(name)}&dates=${formatGCALDate(startTime)}/${formatGCALDate(endTime)}&details=${encodeURIComponent(`Contest URL: ${url}`)}`;


  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 flex flex-col overflow-hidden">
      <div className="p-5 flex-grow">
        <div className="flex justify-between items-start mb-3">
          <PlatformLogo platform={platform} />
          {isOngoing && (
            <span className="px-2 py-1 text-xs font-bold rounded-full bg-red-500/10 text-red-500 animate-pulse">
              Ongoing
            </span>
          )}
        </div>
        <h3 className="text-xl font-bold mb-2 text-slate-800 dark:text-slate-100">{name}</h3>
        
        <div className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
          <p><strong>Starts:</strong> {formatDateTime(startTime)}</p>
          <p><strong>Ends:</strong> {formatDateTime(endTime)}</p>
          <p><strong>Duration:</strong> {getDuration()}</p>
        </div>
      </div>

      <div className="bg-slate-50 dark:bg-slate-700/50 p-4 flex justify-between items-center gap-2">
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 text-center px-4 py-2 text-sm font-semibold text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/50 rounded-md hover:bg-blue-200 dark:hover:bg-blue-800/50 transition-colors"
        >
          Visit Contest
        </a>
        <a
          href={gcalLink}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 text-center px-4 py-2 text-sm font-semibold text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-900/50 rounded-md hover:bg-green-200 dark:hover:bg-green-800/50 transition-colors"
        >
          Add to Calendar
        </a>
      </div>
    </div>
  );
};

export default ContestCard;
